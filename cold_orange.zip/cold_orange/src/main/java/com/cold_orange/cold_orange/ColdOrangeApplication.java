package com.cold_orange.cold_orange;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ColdOrangeApplication {

	public static void main(String[] args) {
		SpringApplication.run(ColdOrangeApplication.class, args);
	}

}
