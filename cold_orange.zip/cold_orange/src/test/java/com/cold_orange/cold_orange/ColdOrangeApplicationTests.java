package com.cold_orange.cold_orange;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ColdOrangeApplicationTests {

	@Test
	void contextLoads() {
	}

}
